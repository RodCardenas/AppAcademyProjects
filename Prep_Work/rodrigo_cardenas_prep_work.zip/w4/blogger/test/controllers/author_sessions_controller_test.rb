require 'test_helper'

class AuthorSessionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
