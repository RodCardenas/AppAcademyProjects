# We're going to implement a cipher called the Folding Cipher. Why? Because it
# folds the alphabet in half and uses the adjacent letter.
#
# For example,
# a <=> z
# b <=> y
# c <=> x
# ...
# m <=> n

def folding_cipher(str)
  alphabet = ('a'..'z').to_a
  encoder = Hash.new

  alphabet.each_with_index do |letter, index|
    encoder[letter] = alphabet[25 - index]
  end

  cipher = str.chars.map do |letter|
    encoder[letter]
  end

  cipher.join("")
end

# Write a method, `digital_root(num)`. It should Sum the digits of a positive
# integer. If it is greater than 10, sum the digits of the resulting number.
# Keep repeating until there is only one digit in the result, called the
# "digital root". **Do not use string conversion within your method.**
#
# You may wish to use a helper function, `digital_root_step(num)` which performs
# one step of the process.

def digital_root(num)
  return num if num < 10

  sum = 0
  number = num
  while sum > 10
    digit = number % 10
    number /= 10
    sum += digit
  end

  sum
end

# Jumble sort takes a string and an alphabet. It returns a copy of the string
# with the letters re-ordered according to their positions in the alphabet. If
# no alphabet is passed in, it defaults to normal alphabetical order (a-z).

# Example:
# jumble_sort("hello") => "ehllo"
# jumble_sort("hello", ['o', 'l', 'h', 'e']) => 'olleh'

def jumble_sort(str, alphabet = nil)
  if !alphabet.nil?
    str.chars.sort_by do |letter|
      alphabet.index(letter)
    end.join("")
  else
    str.chars.sort.join("")
  end
end

class Array
  # Write an array method that returns `true` if the array has duplicated
  # values and `false` if it does not
  def dups?
    elements = Hash.new(0)

    self.each do |el|
      elements[el] += 1
    end

    elements.each do |el,count|
      return true if count > 1
    end

    false
  end
end

class String
  # Returns an array of all the subwords of the string that appear in the
  # dictionary argument. The method does NOT return any duplicates.

  def real_words_in_string(dictionary)
    real_words = []

    start_lttr = 0
    while start_lttr < self.length
    end_lttr = 0
      while end_lttr < self.length
        pos_word = self[start_lttr..end_lttr]
        real_words << pos_word if dictionary.include?(pos_word) && !real_words.include?(pos_word)

        end_lttr += 1
      end
      start_lttr += 1
    end

    real_words
  end
end

# Write a method that returns the factors of a number in ascending order.

def factors(num)
  factors = []

  1.upto(num) do |candidate|
    factors << candidate if num % candidate == 0
  end

  factors
end
